def insertionsort(a):
    for step in range(1,len(a)):
        key=a[step]
        j=step-1
        while j>=0 and key<a[j]:
            a[j+1]=a[j]
            j=j-1
        a[j+1]=key
data=[9,5,1,4,3]
insertionsort(data)
print(data)
