def selectionsort(arr,size):
    for step in range(size):
        minval=step
        for i in range(step+1,size):
            if arr[i]<arr[minval]:
                minval=i
    arr[step],arr[minval]=arr[minval],arr[step]

data=[-2,45,0,11,9]
size=len(data)
selectionsort(data,size)
print("sorted array:")
print(data)